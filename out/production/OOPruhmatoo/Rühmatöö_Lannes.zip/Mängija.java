public class Mängija {
    String nimi;


    public String getNimi() {
        return nimi;
    }

    public Mängija(String nimi) {
        this.nimi = nimi;
    }

}
